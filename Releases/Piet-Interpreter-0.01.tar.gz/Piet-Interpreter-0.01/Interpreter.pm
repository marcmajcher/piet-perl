package Piet::Interpreter;

use 5.6.1;
use strict;
use Image::Magick;
use Class::Struct;

our $VERSION = '0.01';

#  Initialize variables and lookup tables

$| = 1;     #  buffer bad.

my %hex2c  = ( 'FFC0C0' => 'light red',	       'FFFFC0' => 'light yellow',
	       'C0FFC0' => 'light green',      'C0FFFF' => 'light cyan',
	       'C0C0FF' => 'light blue',       'FFC0FF' => 'light magenta',
	       'FF0000' => 'red',	       'FFFF00' => 'yellow',
	       '00FF00' => 'green',	       '00FFFF' => 'cyan',
	       '0000FF' => 'blue',	       'FF00FF' => 'magenta',
	       'C00000' => 'dark red',	       'C0C000' => 'dark yellow',
	       '00C000' => 'dark green',       '00C0C0' => 'dark cyan',
	       '0000C0' => 'dark blue',	       'C000C0' => 'dark magenta',
	       'FFFFFF' => 'white',	       '000000' => 'black',
	       );

my %hex2a  = ( 'FFC0C0' => 'lR', 'FFFFC0' => 'lY', 'C0FFC0' => 'lG',
	       'C0FFFF' => 'lC', 'C0C0FF' => 'lB', 'FFC0FF' => 'lM',
	       'FF0000' => ' R', 'FFFF00' => ' Y', '00FF00' => ' G',
	       '00FFFF' => ' C', '0000FF' => ' B', 'FF00FF' => ' M',
	       'C00000' => 'dR', 'C0C000' => 'dY', '00C000' => 'dG',
	       '00C0C0' => 'dC', '0000C0' => 'dB', 'C000C0' => 'dM',
	       'FFFFFF' => 'Wt', '000000' => 'Bk',
	       );

my %hex2hue  = ( 'FFC0C0' => 0, 'FFFFC0' => 1, 'C0FFC0' => 2,
		 'C0FFFF' => 3, 'C0C0FF' => 4, 'FFC0FF' => 5,
		 'FF0000' => 0, 'FFFF00' => 1, '00FF00' => 2,
		 '00FFFF' => 3, '0000FF' => 4, 'FF00FF' => 5,
		 'C00000' => 0, 'C0C000' => 1, '00C000' => 2,
		 '00C0C0' => 3, '0000C0' => 4, 'C000C0' => 5,
		 'FFFFFF' => -1, '000000' => -1,
		 );

my %hex2light  = ( 'FFC0C0' => 0, 'FFFFC0' => 0, 'C0FFC0' => 0,
		   'C0FFFF' => 0, 'C0C0FF' => 0, 'FFC0FF' => 0,
		   'FF0000' => 1, 'FFFF00' => 1, '00FF00' => 1,
		   '00FFFF' => 1, '0000FF' => 1, 'FF00FF' => 1,
		   'C00000' => 2, 'C0C000' => 2, '00C000' => 2,
		   '00C0C0' => 2, '0000C0' => 2, 'C000C0' => 2,
		   'FFFFFF' => -1, '000000' => -1,
		   );

my @do_arr = (
	      [ 'do_noop',      'do_push',     'do_pop' ],
	      [ 'do_add',       'do_subtract', 'do_multiply' ],
	      [ 'do_divide',    'do_mod',      'do_not' ],
	      [ 'do_greater',   'do_pointer',  'do_switch' ],
	      [ 'do_duplicate', 'do_roll',     'do_in_n' ],
	      [ 'do_in_c',      'do_out_n',    'do_out_c' ],
	      );




struct ( Piet::Interpreter => {
        image => '$',
	debug => '$',
        warn => '$',
	trace => '$',
        codel_size => '$',
        dp => '$',
        cc => '$',
        stack => '@',
});
 

sub init_image {

    #  usage:  $piet->init_image('mycode.gif');
    #
    #     Loads the specified image (usually a gif or jpg) into the
    #     interpreter for processing.  Since the interpreter cannot run 
    #     without an image to work with, we also cheat a bit here by using 
    #     this method to initialize stuff for the interpreter.  Because of 
    #     this hackiness, this method must be called before any others, 
    #     such as codel_size(), as it will reset them to the defaults.
    #     We also do a bad thing by breaking the encapsulation on Class::Struct,
    #     to initialize the stack.  This may break in future versions of the
    #     module, but whatcha gonna do?

    my $self   = shift;
    my $infile = shift || do { warn "No image file given in Piet::Interpreter::image()";
			       return };
    (-f $infile) || do { warn "Cannot find file $infile in Piet::Interpreter::image()";
			 return };

    #  Initialize (or re-initialize) interpreter variables

    $self->image($infile);
    $self->codel_size(1);
    $self->{'Piet::Interpreter::stack'} = [];   #  this may break in later versions 
}

##  hack, hack.

sub stack_push {
    my ($self, $value) = @_;
    push(@{$self->{'Piet::Interpreter::stack'}},$value);
}

sub stack_pop {
    my $self = shift;
    return pop @{$self->{'Piet::Interpreter::stack'}};
}


#  These two little guys look identical, but are really used for two different things.

sub _debug {
    my $self = shift;
    if ($self->debug) {
        my $message = shift;
	print "$message\n";
    }
}

sub _trace {
    my $self = shift;
    if ($self->trace) {
	my $message = shift ;
	print "  $message\n";
    }
}


sub run {
    #  This is where the magic all happens.

    my $self = shift; 
    $self->dp(0);        #   Direction Pointer:  0=right, 1=down, 2=left, 3=up
    $self->cc(-1);       #       Codel Chooser: -1=left, 1=right
    my $cx =  0;         #  Current x position
    my $cy =  0;         #  Current y position

    my $img = Image::Magick->new;
    $img->Read(filename=>$self->image);

    my $cols = $img->Get('columns');
    my $rows = $img->Get('rows');

    # todo:
    #  "smooth" image; verify and compress large codels (codel_size > 1), 
    #  normalize colors, and whitewash (or blackwash) non-standard colors.

    $self->print_img($img) if $self->debug;

    my $old_color = HexColor($img->Get("pixel[$cx,$cy]"));
    my $block_value;
    my $change = 0;

    while (1) {
    
	#  get the current codel color block

	my @block = get_color_block($img, $cx, $cy,$self->codel_size);
	$block_value = scalar @block;
	
	my $try = 8;
	while ($try) {
	    #  find edge of current codel color block in direction of dp
	    #  find codel on edge furthest in direction of cc
	    my ($ex,$ey)  = get_edge_codel($self->dp, $self->cc, @block);
	    
	    #  move to codel immediately in the direction of dp, if possible
	    my ($nx, $ny) = $self->get_new_codel($self->dp, $ex, $ey);
	    
	    #  if pointer can't move, rotate/toggle, and try again
	    
	    if (!is_valid($nx,$ny) || is_black($img,$nx,$ny)) {
		if ($change) {
		    $self->dp(($self->dp + 1) % 4);
		    $change = 0;
		}
		else {
		    $self->cc($self->cc * -1);
		    $change = 1;
		}
		my $why = is_black($img,$nx,$ny)?"black":"invalid";
		$self->_debug(" trying again ($why at $nx,$ny) - DP: ".
			      $self->dp."  CC: ".$self->cc);
		$try--;
	    }
	    elsif (is_white($img,$nx,$ny)) {
		#  slide across white squares
		$self->_debug("EX: $ex  EY: $ey  =>  NX: $nx  NY: $ny   (DP: ".
			      $self->dp."  CC: ".$self->cc.") (WHITE)");
		$old_color = "FFFFFF";
		$cx = $nx;
		$cy = $ny;
		last;
	    }
	    else {
		my $new_color = HexColor($img->Get("pixel[$nx,$ny]"));
		$self->_debug("EX: $ex  EY: $ey  =>  NX: $nx  NY: $ny   (DP: ".
			      $self->dp."  CC: ".$self->cc.")");
		
		$self->do_action($old_color, $new_color, $block_value) unless
		    ($hex2c{$old_color} eq "white");
		
		# hack, hack
		$self->_debug("STACK:  ".join(",",@{$self->{'Piet::Interpreter::stack'}}));

		$old_color = $new_color;
		$cx = $nx;
		$cy = $ny;
		last;
	    }
	}
	last unless $try;
    }

    #### little helper buddies

sub is_valid {
    my ($x,$y) = @_;
    return !(($x<0) || ($y<0) ||
	     ($x>=$cols) || ($y>=$rows));
    #  add check for "black" codel?
    
}

sub is_black {
    my ($img,$x,$y) = @_;
    my $color = $img->Get("pixel[$x,$y]");
    return $hex2c{HexColor($color)} eq "black";
}

sub is_white {
    my ($img,$x,$y) = @_;
    my $color = HexColor($img->Get("pixel[$x,$y]"));
    return (!defined $hex2c{$color}) || ($hex2c{$color} eq "white");
}

}

###

sub get_new_codel {
    
    my $self = shift;
    
    #  returns a point in the direction of the dp from x,y

    my ($dp, $x, $y) = @_;
    
    if    ($dp == 1) { $y+=$self->codel_size }
    elsif ($dp == 2) { $x-=$self->codel_size }
    elsif ($dp == 3) { $y-=$self->codel_size }
    else             { $x+=$self->codel_size }
    
    return ($x, $y);
}


sub get_edge_codel {

    #  returns point on far edge of block
    
    my ($dp, $cc, @block) = @_;
    
    #  get edge by finding the furthest index, then getting all points with that index

    my @edge;
    my $codel;

    if ($dp == 1) {
	my @sorted = sort {$$b[1] <=> $$a[1]} @block;
	@edge = sort {$$a[0] <=> $$b[0]} grep {$$_[1] == $sorted[0][1]} @sorted;
	$codel = ($cc>0)?$edge[0]:$edge[$#edge];
    }
    elsif ($dp == 2) {
	my @sorted = sort {$$a[0] <=> $$b[0]} @block;
	@edge = sort {$$a[1] <=> $$b[1]} grep {$$_[0] == $sorted[0][0]} @sorted;
	$codel = ($cc>0)?$edge[0]:$edge[$#edge];
    }
    elsif ($dp == 3) {
	my @sorted = sort {$$a[1] <=> $$b[1]} @block;
	@edge = sort {$$a[0] <=> $$b[0]} grep {$$_[1] == $sorted[0][1]} @sorted;
	$codel = ($cc>0)?$edge[$#edge]:$edge[0];
    }
    else {
	my @sorted = sort {$$b[0] <=> $$a[0]} @block;
	@edge = sort {$$a[1] <=> $$b[1]} grep {$$_[0] == $sorted[0][0]} @sorted;
	$codel = ($cc>0)?$edge[$#edge]:$edge[0];
    }

    return @$codel;
}

{
    my %seen;
    
    sub get_color_block {
	
	#  returns list of points in current color block
	
	my ($img, $x, $y, $size) = @_;

	%seen = ("$x\_$y",1);
	return _neighbor_list($img,$x,$y,$size);

	#  todo:  color block memoization
    }

    sub _neighbor_list {
	my ($img,$x,$y,$size) = @_;
	
	my @neighbors = ();
	my $color = $img->Get("pixel[$x,$y]");

	for my $i (-$size,0,$size) {
	    for my $j (-$size,0,$size) {
		next if (abs($i) == abs($j));

		my $m=$x+$i;
		my $n=$y+$j;

		next unless is_valid($m,$n);

		if ((!defined $seen{"$m\_$n"}) &&
		    ($img->Get("pixel[$m,$n]") eq $color)){
		    push (@neighbors, [$m,$n]);
		}
		$seen{"$m\_$n"} = 1;
	    }
	}
	return ([$x,$y],map {_neighbor_list($img,$$_[0],$$_[1],$size)} @neighbors);
    }

}
 

sub print_img {
    my $self = shift;
    my $img = shift || return;

    my $cols = $img->Get('columns');
    my $rows = $img->Get('rows');
    print "Image ".$self->image.": ($cols x $rows)\n";
    
    my $j = 0;
    while ($j<=($rows-1)) {
	my $i = 0;
	while ($i<=($cols-1)) {
	    my $color = $img->Get("pixel[$i,$j]");
	    my $hexcolor = HexColor($color);
	    print "$hex2a{$hexcolor} ";
	    $i += $self->codel_size;
	}
	print "\n";
	$j += $self->codel_size;
    }
}


sub HexColor {
    my ($number, $hex);
    (shift @_) =~ /^(\d+),(\d+),(\d+)/;
    for $number ($1,$2,$3) {
	$hex .= sprintf("%02X", $number/257);
    }
    return $hex;
}


#  Piet function subroutines

sub do_noop {
    my $self = shift;
    my $block_value = shift;

    $self->_debug(" OPER: noop");
    $self->_trace("NOOP");
}

sub do_push {
    my $self = shift;
    my $block_value = shift;

    $self->_debug(" OPER: push ($block_value)");
    $self->_trace("PUSH $block_value");

    $self->stack_push($block_value);
}

sub do_pop {
    my $self = shift;
    my $block_value = shift;

    my $tmp = $self->stack_pop;

    $self->_debug(" OPER: pop");
    $self->_trace("POP  $tmp");
}

sub do_add {
    my $self = shift;
    my $block_value = shift;

    my $top  = $self->stack_pop;
    my $next = $self->stack_pop;
    $self->stack_push($next+$top);

    $self->_debug(" OPER: add     ".($next+$top));
    $self->_trace("ADD  $next $top");
}

sub do_subtract {
    my $self = shift;
    my $block_value = shift;

    my $top  = $self->stack_pop;
    my $next = $self->stack_pop;
    $self->stack_push($next-$top);

    $self->_debug(" OPER: subtract    ".($next-$top));
    $self->_trace("SUB  $next $top");
}

sub do_multiply {
    my $self = shift;
    my $block_value = shift;

    my $top  = $self->stack_pop;
    my $next = $self->stack_pop;
    $self->stack_push($next*$top);

    $self->_debug(" OPER: multiply    ".($next*$top));
    $self->_trace("MULT $next $top");
}

sub do_divide {
    my $self = shift;
    my $block_value = shift;

    my $top  = $self->stack_pop;
    my $next = $self->stack_pop;
    $self->stack_push(int($next/$top));

    $self->_debug(" OPER: divide    ".(int($next/$top)));
    $self->_trace("DIV  $next $top");
}

sub do_mod {
    my $self = shift;
    my $block_value = shift;

    my $top  = $self->stack_pop;
    my $next = $self->stack_pop;
    $self->stack_push($next%$top);

    $self->_debug(" OPER: mod     ".($next%$top));
    $self->_trace("MOD  $next $top");
}

sub do_not {
    my $self = shift;
    my $block_value = shift;

    my $top = $self->stack_pop;
    $self->stack_push(!$top+0);

    $self->_debug(" OPER: not    ".(!$top+0));
    $self->_trace("NOT  $top");
}

sub do_greater {
    my $self = shift;
    my $block_value = shift;

    my $top  = $self->stack_pop;
    my $next = $self->stack_pop;
    $self->stack_push((($next>$top)?1:0)+0);

    $self->_debug(" OPER: greater   ".((($next>$top)?1:0)+0));
    $self->_trace("GTR  $next $top");
}

sub do_pointer {
    my $self = shift;
    my $block_value = shift;

    my $top = $self->stack_pop;

    $self->_debug(" OPER: pointer  ($top)");
    $self->_trace("PNTR $top");

    $self->dp(($self->dp + $top) % 4);
}

sub do_switch {
    my $self = shift;
    my $block_value = shift;

    my $top = $self->stack_pop;

    $self->_debug(" OPER: switch   ($top)");
    $self->_trace("SWCH $top");

    $self->cc($self->cc * -1) if ($top %2);
}

sub do_duplicate {
    my $self = shift;
    my $block_value = shift;

    my $top = $self->stack_pop;
    $self->stack_push($top);
    $self->stack_push($top);

    $self->_debug(" OPER: duplicate  ($top)");
    $self->_trace("DUP  $top");
}

sub do_roll {
    my $self = shift;
    my $block_value = shift;

    # there's got to be one bad apple in the bunch...
    my $num   = $self->stack_pop;
    my $depth = $self->stack_pop;

    $self->_debug(" OPER: roll:  $num times, $depth deep");
    $self->_trace("ROLL $depth $num");

    $num = $num % $depth;
    return if ($depth <= 0);
    return if ($num   == 0);

    my @stack = @{$self->{'Piet::Interpreter::stack'}};  #  oooo, breaky breaky
    my @tmp = @stack[($#stack-$depth+1)..$#stack]; 

    if ($num>0) {
	@tmp = (@tmp[-$num..-1], @tmp[0..($#tmp-$num)]); 
    }
    else {
	@tmp = (@tmp[-$num..$#tmp], @tmp[0..(-$num-1)]); 
    }

    splice(@stack, $#stack-$depth+1, $depth, @tmp);
    $self->{'Piet::Interpreter::stack'} = \@stack;
}

sub do_in_n {
    my $self = shift;
    my $block_value = shift;

    my $c = ord(&getone);

    $self->_debug(" OPER: in_n:  got $c");
    $self->_trace("N_IN");

    $self->stack_push($c);
}

sub do_out_n {
    my $self = shift;
    my $block_value = shift;

    my $top = $self->stack_pop;
    print $top unless $self->trace;

    $self->_debug(" OPER: out_n      OUT - $top");
    $self->_trace("NOUT $top");
}

sub do_in_c {
    my $self = shift;
    my $block_value = shift;

    my $c = &getone;

    $self->_debug(" OPER: in_c:  got $c");
    $self->_trace("C_IN");

    $self->stack_push($c);
}

sub do_out_c {
    my $self = shift;
    my $block_value = shift;

    my $top = chr($self->stack_pop);
    print $top unless $self->trace;

    $self->_debug(" OPER: out_c       OUT - $top");
    $self->_trace("COUT $top");
}



sub do_action {
    my $self = shift;
    my ($old, $new, $value) = @_;

    $self->_debug("  Old Color: $hex2c{$old} => New Color: $hex2c{$new}");
    my $diff_hue   = ($hex2hue{$new}   - $hex2hue{$old})   % 6;
    my $diff_light = ($hex2light{$new} - $hex2light{$old}) % 3;

#    &{$do_arr[$diff_hue][$diff_light]};

    my $method = $do_arr[$diff_hue][$diff_light];
    $self->$method($value);
}



sub usage {
    print <<USE;

This script implements the Piet programming language, described in full at:
  http://www.physics.usyd.edu.au/~mar/esoteric/piet.html

You must supply an image as an argument, like so:
  piet [-d] [-w] [-b] [-s <num>] hello.gif

    Flags:
      -d : turns on debugging
      -w : turns on interpreter warnings
      -t : trace mode - prints operations 
      -s : sets codel size in pixel width (default 1)
      -b : sets undefined colors to black (default white) (not implemented)

Thank you, please come again.

USE
    exit;
}

#  I'm going to assume that Term::ReadKey isn't installed...

BEGIN { use POSIX qw(:termios_h);
        my ($term, $oterm, $echo, $noecho, $fd_stdin);
        $fd_stdin = fileno(STDIN);
        $term     = POSIX::Termios->new();
        $term->getattr($fd_stdin);
        $oterm    = $term->getlflag();
        $echo     = ECHO | ECHOK | ICANON;
        $noecho   = $oterm & ~$echo;
	
	sub getone {
	    my $key = '';
	    $term->setlflag($oterm);
	    $term->setcc(VTIME, 0);
	    $term->setattr($fd_stdin, TCSANOW);
	    sysread(STDIN, $key, 1);
	    return $key;
	}
}


1;
__END__


=head1 NAME

Piet::Interpreter - Interpreter for the Piet programming language

=head1 SYNOPSIS

    use Piet::Interpreter;

    my $p = Piet::Interpreter->new;
    $p->image('my_code.gif');
    $p->run;

=head1 DESCRIPTION

Piet is a programming language in which programs look like abstract
paintings. The language is named after Piet Mondrian, who pioneered
the field of geometric abstract art.  The language is fully described
at http://www.physics.usyd.edu.au/~mar/esoteric/piet.html.  A Piet
program is an image file, usually a gif, which uses a set of 20 colors
and the transitions between blocks of those colors to define a series
of instructions and program flow.  See the above URL for more details.

Since Piet is a visual language, an image parsing mechanism is
required.  This module uses Image::Magick, so it would be to your
advantage to download, install, and test that module and its
related stuff before trying to use this one.  I know, it's sort
of a pain in the ass, but then again, so is Piet.

=head1 AUTHOR

Marc Majcher (piet-interpreter@majcher.com)

=head1 SEE ALSO

L<http://www.physics.usyd.edu.au/~mar/esoteric/piet.html>

=cut
